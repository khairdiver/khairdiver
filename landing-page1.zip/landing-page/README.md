
Hello,

This is the landing page project.
We using her
HTML -  CSS - JAVASCRIPT

The first  specification (the Navigation)
The second specification (the dynamic active)
The third specification  (the scrolling effect)


In this project we change the static web project to  dynamic project.

What we have to do her :

Manipulating the DOM exercise.
* Exercise programmatically builds navigation,
* scrolls to anchors from navigation,
* and highlights section in viewport upon scrolling.


Building 4 content sections in the HTML.
Define Global Variables.
Build the Navigation menu.
Looping over all sections.
Append all elements to the navigation.
Adding some styling to the active state "section".
Add class 'active' to section when near top of viewport.
All Projects features is useable across all screen sizes and view ports.
Given the section position a unique class and remove that class from any other section.
Adding the active class.
Implementing the actual function.
Add the functionality to scroll to sections.
When the user click a link in the navbar the project should scroll down to that section.
Adding Style Color to the selector section, so When I click on it his color will change and the other not.

Thanks,
