

// sections global variables
const sections = document.querySelectorAll('section');
// navigation global variables
const navigation = document.getElementById('navbar__list');


const navBuilder = () => {

    let navList = '';
    // looping over all sections
    sections.forEach(section => {

          const sectionID = section.id;
          const sectionDataNav = section.dataset.nav;

    navList += `<li><a class="menu__link" href="#${sectionID}">${sectionDataNav}</a></li>`;

});

    // append all elements to the navigation
    navigation.innerHTML = navList;
};


navBuilder();

// Add class 'active' to section when near top of viewport

// getting the bigest value that's less or equal to the number
  const offset = (section) => {
        return Math.floor(section.getBoundingClientRect().top);
};

// remove the active class
// set the normal background color for the none selector section
  const removeActive = (section) => {
        section.classList.remove('your-active-class');
        section.style.cssText = "background-color: linear-gradient(0deg, rgba(255,255,255,.1) 0%, rgba(255,255,255,.2) 100%)";

};
// seting the active class
// the selecting section take A Kiwi color. :-)
  const addActive = (conditional, section) => {
        if(conditional){
        section.classList.add('your-active-class');
        section.style.cssText = "background-color: #AEC33A;";
      };
};

//inquiry the actual function

 const sectionAct = () => {
       sections.forEach(section => {
              const elementseting = offset(section);

       inviewport = () => elementseting < 170 && elementseting >= -170;

        removeActive(section);
        addActive(inviewport(),section);

    });
};


window.addEventListener('scroll' ,sectionAct);

// Scroll to anchor ID using scrollTO event
// looping to all the Links
// loop over all the section

const scrolling = () => {
      const links = document.querySelectorAll('.navbar__menu a');
      links.forEach(link => {
      link.addEventListener('click', () => {
              for(i = 0 ; i<sections ; i++){
                sections[i].addEventListener("click",sectionScroll(link));
            }
        });
    });

};

 scrolling();


 
