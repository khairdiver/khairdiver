
// API Key
const baseURL = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const APIkey = '&appid=f6ff72026059d05795fdf0e65cd67cc2&units=metric';

// Global Variables 
// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'.'+ d.getDate()+'.'+ d.getFullYear();

//Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click',performAction);

//Function called by event listener
function performAction(e){
    e.preventDefault()
    const ZIPcode = document.getElementById('zip').value;
    const userResponse = document.getElementById('feelings').value;

    getWeather(baseURL,ZIPcode,APIkey)
    .then(function(data){
        postData('http://localhost:8000/data',{date : newDate, temp : data.main.temp, content : userResponse})
        .then(function(){
            UpdateUI();
        })
    }) 
}

//function to Get web API Data
async function getWeather(baseURL,ZIPcode,APIkey){
    const response = await fetch(baseURL+ZIPcode+APIkey);
    try{
        const newData = await response.json();
        return newData;
    }
    catch(error){
        console.log('error' + error);
    }
}

//Faction to Post data
async function postData( url = '', data = {}){
    const response = await fetch(url, {
    method: 'POST', 
    credentials: 'same-origin',
    headers: {
        'Content-Type': 'application/json',
    },     
    body: JSON.stringify(data), 
  });

    try {
      const newData = await response.json();
      return newData;
    }catch(error) {
      console.log("error", error);
    }
}

// Function to Get Project Data
async function UpdateUI(){

    const response =await fetch('http://localhost:8000/all');
    try{
        const Data = await response.json();
        document.getElementById('temp').innerHTML = `Today is ${Data.temp}`;
        document.getElementById('date').innerHTML = `The Temprature is ${Data.date}`;
        document.getElementById('content').innerHTML = `I feel ${Data.content}`;
    }catch(error){
        console.log('error' + error);
    }
}


